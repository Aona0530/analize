import React, { useState, useEffect } from 'react';
import { Activity, TrendingUp, Camera, GraduationCap, Mountain, Target } from 'lucide-react';
import Header from './components/Header';
import Overview from './sections/Overview';
import CameraChannels from './sections/CameraChannels';
import UniversityChannels from './sections/UniversityChannels';
import MountainChannels from './sections/MountainChannels';
import GrowthStrategy from './sections/GrowthStrategy';
import Footer from './components/Footer';
import './App.css';

function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  const sections = [
    { id: 'home', title: 'ホーム (概要)', icon: <Activity size={18} /> },
    { id: 'camera-channels', title: 'カメラ系チャンネル', icon: <Camera size={18} /> },
    { id: 'university-channels', title: '大学生YouTuber', icon: <GraduationCap size={18} /> },
    { id: 'mountain-photo-channels', title: '登山・写真系YouTuber', icon: <Mountain size={18} /> },
    { id: 'growth-strategy', title: '成長戦略とターゲット', icon: <Target size={18} /> }
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleSectionChange = (sectionId: string) => {
    setActiveSection(sectionId);
    setIsMobileMenuOpen(false);
  };

  useEffect(() => {
    document.title = '統合YouTubeチャンネル分析ダッシュボード';
  }, []);

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'home':
        return <Overview onSectionChange={handleSectionChange} />;
      case 'camera-channels':
        return <CameraChannels />;
      case 'university-channels':
        return <UniversityChannels />;
      case 'mountain-photo-channels':
        return <MountainChannels />;
      case 'growth-strategy':
        return <GrowthStrategy />;
      default:
        return <Overview onSectionChange={handleSectionChange} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-700 font-sans antialiased">
      <Header 
        sections={sections} 
        activeSection={activeSection} 
        onSectionChange={handleSectionChange}
        isMobileMenuOpen={isMobileMenuOpen}
        toggleMobileMenu={toggleMobileMenu}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {renderActiveSection()}
      </main>

      <Footer />
    </div>
  );
}

export default App;