import React, { useRef, useEffect, useState } from 'react';
import Chart from 'chart.js/auto';

interface ChartContainerProps {
  id: string;
  type: 'bar' | 'line' | 'pie' | 'doughnut' | 'radar' | 'polarArea' | 'bubble' | 'scatter';
  data: any;
  options?: any;
  height?: string;
  className?: string;
}

const ChartContainer: React.FC<ChartContainerProps> = ({
  id,
  type,
  data,
  options = {},
  height = '300px',
  className = '',
}) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const [chartInstance, setChartInstance] = useState<Chart | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  // Destroy chart on unmount
  useEffect(() => {
    return () => {
      if (chartInstance) {
        chartInstance.destroy();
      }
    };
  }, [chartInstance]);

  // Create and update chart when data or options change
  useEffect(() => {
    if (!chartRef.current || !isVisible) return;

    // Default options for better visual appearance
    const defaultOptions = {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 800,
        easing: 'easeOutQuart',
      },
      plugins: {
        legend: {
          labels: {
            font: {
              family: "'Noto Sans JP', sans-serif",
            },
          },
        },
        tooltip: {
          backgroundColor: 'rgba(17, 24, 39, 0.8)',
          titleFont: {
            family: "'Noto Sans JP', sans-serif",
            size: 13,
          },
          bodyFont: {
            family: "'Noto Sans JP', sans-serif",
            size: 12,
          },
          padding: 12,
          cornerRadius: 6,
          displayColors: true,
        },
      },
    };

    // Merge default options with provided options
    const mergedOptions = { ...defaultOptions, ...options };

    // If chart instance exists, update it
    if (chartInstance) {
      chartInstance.data = data;
      chartInstance.options = mergedOptions;
      chartInstance.update();
    } else {
      // Create new chart
      const newChartInstance = new Chart(chartRef.current, {
        type,
        data,
        options: mergedOptions,
      });
      setChartInstance(newChartInstance);
    }
  }, [chartRef, data, options, type, isVisible]);

  // Check if the chart is visible on screen
  useEffect(() => {
    if (!chartRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );

    observer.observe(chartRef.current);

    return () => {
      observer.disconnect();
    };
  }, [chartRef]);

  return (
    <div className={`chart-container ${className}`} style={{ height }}>
      <canvas ref={chartRef} id={id}></canvas>
      {!isVisible && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="animate-pulse text-slate-300">
            <svg 
              className="w-10 h-10" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={1.5} 
                d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" 
              />
            </svg>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChartContainer;