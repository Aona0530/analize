import React from 'react';

interface CardProps {
  title?: string;
  icon?: React.ReactNode;
  accentColor?: string;
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}

const Card: React.FC<CardProps> = ({
  title,
  icon,
  accentColor = 'primary',
  children,
  onClick,
  className = '',
}) => {
  const accentColorMap: Record<string, string> = {
    primary: 'text-sky-700',
    secondary: 'text-purple-700',
    accent: 'text-amber-700',
    success: 'text-emerald-700',
    warning: 'text-orange-700',
    error: 'text-red-700',
  };

  const titleColor = accentColorMap[accentColor] || accentColorMap.primary;

  return (
    <div 
      className={`card p-6 ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      {title && (
        <div className="flex items-center mb-3">
          {icon && <span className={`mr-2 ${titleColor}`}>{icon}</span>}
          <h3 className={`font-bold text-xl ${titleColor}`}>{title}</h3>
        </div>
      )}
      {children}
    </div>
  );
};

export default Card;