import React from 'react';
import { Menu, X } from 'lucide-react';

interface HeaderProps {
  sections: {
    id: string;
    title: string;
    icon: React.ReactNode;
  }[];
  activeSection: string;
  onSectionChange: (sectionId: string) => void;
  isMobileMenuOpen: boolean;
  toggleMobileMenu: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  sections, 
  activeSection, 
  onSectionChange, 
  isMobileMenuOpen, 
  toggleMobileMenu 
}) => {
  return (
    <header className="bg-white/80 backdrop-blur-lg sticky top-0 z-30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <h1 className="text-xl md:text-2xl font-bold text-slate-800">
            YouTubeチャンネル分析ダッシュボード
          </h1>
          
          <nav className="hidden md:flex items-center space-x-8 text-sm font-medium">
            {sections.map((section) => (
              <a
                key={section.id}
                href={`#${section.id}`}
                className={`nav-link flex items-center space-x-2 ${
                  activeSection === section.id ? 'active' : ''
                }`}
                onClick={(e) => {
                  e.preventDefault();
                  onSectionChange(section.id);
                }}
              >
                <span>{section.icon}</span>
                <span>{section.title}</span>
              </a>
            ))}
          </nav>
          
          <button
            className="md:hidden p-2 rounded-md text-slate-600 hover:bg-slate-100 focus:outline-none transition-colors"
            onClick={toggleMobileMenu}
            aria-expanded={isMobileMenuOpen}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-200 animate-fade-in">
          {sections.map((section) => (
            <a
              key={section.id}
              href={`#${section.id}`}
              className={`flex items-center space-x-3 py-3 px-4 text-base font-medium ${
                activeSection === section.id
                  ? 'text-primary-600 bg-primary-50'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
              onClick={(e) => {
                e.preventDefault();
                onSectionChange(section.id);
              }}
            >
              <span>{section.icon}</span>
              <span>{section.title}</span>
            </a>
          ))}
        </div>
      )}
    </header>
  );
};

export default Header;