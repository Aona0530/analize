import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-800 text-slate-400 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-sm">
        <p>© {new Date().getFullYear()} 統合YouTubeチャンネル分析ダッシュボード. All rights reserved.</p>
        <p className="mt-1">この分析は提供されたレポートと統合データに基づいて作成されました。</p>
      </div>
    </footer>
  );
};

export default Footer;