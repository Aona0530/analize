// This file contains the data for all channels in the dashboard

// Camera channel data
const cameraChannelData = [
  { id: 'jetdaisuke', name: 'ジェットダイスケ/JETDAISUKE', subs: 281000, link: 'https://www.youtube.com/@JETDAISUKE', summary: 'カメラ・写真系YouTuberの先駆け的存在。製品レビューや体験動画を中心に、初歩から応用まで幅広くカバー。大学講師も務めるなど、その専門知識と経験が信頼性を高めている。', mostViewed: { title: 'カプセルトミカ、日産GT-R等 食玩おまけ', views: 15000000 }, leastViewed: [{ title: '【ミニ旅】特急サンダーバード金沢行き', views: 3400 }, { title: 'Viltrox AF 50mm F2.0 AIR', views: 5500 }, { title: '[Preview] AF 14-24mm F2.8 FE', views: 9800 }], shortsAnalysis: 'データ不足により、ショートと通常動画の明確な比較は困難。ただし、最も再生された動画がカメラと無関係な食玩レビューであることから、幅広いコンテンツで視聴者を獲得してきた歴史がうかがえる。' },
  { id: 'yutobi', name: 'ゆ〜とび', subs: 173000, link: 'https://www.youtube.com/@yutobi', summary: '風景写真をメインに、撮影の裏側やコツを初心者にも分かりやすく解説。前ボケや背景ボケを多用した美しい作風が人気。近年はVlogにも注力し、コンテンツの幅を広げている。', mostViewed: { title: '【豪雨】50mmF1.4単焦点縛り！', views: 348000 }, leastViewed: [{ title: '"kyu camera"の徹底分析', views: 10000 }, { title: 'DJI Osmo Mobile 7P', views: 17000 }, { title: 'Hasselblad XCD 3,2 4,520 35E開封', views: 26000 }], shortsAnalysis: 'ショート動画「iPhoneでも撮れるエモい人の撮り方」(111K再生)も高い再生数を記録。手軽なハウツー系ショートで新規層にリーチを広げつつ、通常動画でより深い情報を提供するバランス型戦略。' },
  { id: 'sunsetstudio', name: 'サンセットスタジオTV', subs: 110000, link: 'https://www.youtube.com/@sunsetstudioTV', summary: 'カメラの難しい知識を省き、視聴者が楽しく撮影できるよう導くことを重視。写真だけでなくVlogなど動画コンテンツも強化し、実用的な撮影スキル向上に貢献している。', mostViewed: { title: '情報なし', views: 0 }, leastViewed: [{ title: 'ナカモトダイスケさんにお会いしてきた', views: 698 }, { title: 'サンセットスタジオ nobuhiro ootuka', views: 1 }, { title: '情報なし', views: 0 }], shortsAnalysis: '提供されたデータではショート動画に関する十分な情報がなく、分析は困難。' },
  { id: 'watarunishida', name: 'Wataru Nishida 西田航', subs: 98500, link: 'https://www.youtube.com/@watarunishida', summary: '撮影技法のレクチャーや機材紹介がメインで、中上級者向けの専門的な内容が多い。特にカメラやレンズの比較レビューが豊富で、写真へのストイックな取り組み方が特徴。', mostViewed: { title: '【感動！】ライカのトップページに僕の作品が', views: 20000 }, leastViewed: [{ title: 'Leica M11-PとM11-Dの使い分け', views: 2200 }, { title: '情報なし', views: 0 }, { title: '情報なし', views: 0 }], shortsAnalysis: 'メンバーシップ限定動画が多く、公開されているショート動画のデータは限定的。メインコンテンツは専門性の高い長尺動画に集中していると推測される。' },
  { id: 'yazawatakanori', name: '矢沢隆則', subs: 59300, link: 'https://www.youtube.com/@TakanoriYazawa', summary: 'フォトグラファー、レースクイーン専門家として25年の活動実績を持つ。メインチャンネルでは、カメラ・写真に関する真面目な情報を発信している。', mostViewed: { title: '情報なし', views: 0 }, leastViewed: [{ title: '情報なし', views: 0 }, { title: '情報なし', views: 0 }, { title: '情報なし', views: 0 }], shortsAnalysis: '提供されたデータからは動画パフォーマンスに関する情報が取得できず、分析は困難。' },
  { id: 'camegaku', name: 'カメラの学校', subs: 47700, link: 'https://www.youtube.com/@camegaku', summary: 'デジタルハリウッド株式会社が運営する教育系チャンネル。一眼レフ初心者を主な対象とし、カメラの基本テクニックや用語解説を提供。コンテンツは長期間にわたり視聴され続ける傾向がある。', mostViewed: { title: '【初心者】夜景の撮り方', views: 240000 }, leastViewed: [{ title: '横須賀で学ぶカメラテクニック～銅像～', views: 18000 }, { title: '光の中での夜景ポートレイト', views: 20000 }, { title: 'すばらしすぎるボケ味と合わせずらいピント', views: 21000 }], shortsAnalysis: 'ショート動画に関するデータは不足。チャンネルの強みは、普遍的で検索されやすい「ロングテール型」の教育コンテンツにある。' },
  { id: 'pharaochannel', name: 'ふぁらおチャンネル', subs: 47600, link: 'https://www.youtube.com/@pharaohphoto', summary: 'エンターテイメント性が非常に高く、カメラ経験者・未経験者問わず楽しめる動画が特徴。動画構成に優れ、作品のクオリティは高い評価を得ている。', mostViewed: { title: 'インスタ女子にブチ切れながら写真を撮る男 #Shorts', views: 954000 }, leastViewed: [{ title: '子どもへの正しい接し方と撮り方', views: 28000 }, { title: '撮影体験を劇的に向上させる魔法ギア', views: 29000 }, { title: '新製品先行レビュー依頼相手を完全に間違えた企業', views: 56000 }], shortsAnalysis: '「インスタ女子にブチ切れ #Shorts」(954K再生) が通常動画をはるかに上回る再生数を記録。エンタメ性の高いショート動画がチャンネルの顔となり、爆発的な拡散力で新規視聴者を獲得する戦略が明確。' },
  { id: 'yusukehayashi', name: '写真家 林 祐介', subs: 32800, link: 'https://www.youtube.com/@yusukehayashi_photo', summary: 'ネイチャーフォトグラファーとして、風景や動物など自然写真を初心者向けに解説。まじめでワイルドな作風が特徴で、基礎から丁寧に教えるスタイル。', mostViewed: { title: 'これで分かる！ 露出補正とヒストグラム', views: 101000 }, leastViewed: [{ title: '撮影のジャンル選びが１番大切な件', views: 4000 }, { title: 'F値13縛り撮影のメリット', views: 4200 }, { title: 'RFレンズで撮る！アラスカの超美麗な自然', views: 3500 }], shortsAnalysis: 'ショート動画「野生の熊」(46K再生)などがあるが、再生数は通常動画のハウツーコンテンツに及ばない。ショートは撮影の裏側を見せるVlog的な役割で、メインは専門的な通常動画。' },
  { id: 'masahirohirose', name: 'Masahiro Hirose', subs: 22900, link: 'https://www.youtube.com/@MasahiroHirose', summary: '端的にまとまっていて見やすいチュートリアル動画が多い。無駄話が少なく、効率的に学びたい視聴者から支持を得ている。', mostViewed: { title: '広角写真を極めるスナップ写真（後編）', views: 20000 }, leastViewed: [{ title: 'ひまわりを超ワイドで撮影', views: 1300 }, { title: '軽くて小さい＆画質の良いカメラ', views: 1400 }, { title: '紫陽花の撮影準備', views: 1700 }], shortsAnalysis: '提供されたデータにショート動画は含まれていない。コンテンツは効率性を重視したチュートリアルに特化している。' },
  { id: 'yuriphoto', name: 'Yuri Photo Channel', subs: 17700, link: 'https://www.youtube.com/@yuriphoto', summary: 'ふんわりとした写真を撮り歩くフォトグラファー。写真レッスン、機材レビュー、旅に関する動画を提供し、ライフスタイルに寄り添った写真表現が魅力。', mostViewed: { title: 'かわいい紫陽花を撮るための4つのポイント', views: 64000 }, leastViewed: [{ title: 'クロアチア #fujifilm #xt5', views: 851 }, { title: '自作のピクチャーコントロール', views: 2400 }, { title: 'model：tsutsumi #PR #pentax17', views: 4500 }], shortsAnalysis: 'ショート動画は旅の記録などに用いられ、再生数は通常動画に比べて低い。メインの視聴者獲得源は、実用的なハウツー系の通常動画。' },
].sort((a, b) => b.subs - a.subs);

// University channel data
const universityChannelData = [
  { id: 0, name: 'QuizKnock', subscribers: 251, genre: '教育・学習系', mostViewed: '【検証】クイズ王ならクイズの最中に結婚報告されても集中して答え続けられる説【ご報告】 (870万回再生)', strategy: '東大生というブランドを活かした高い専門性と、革新的なクイズ企画力で圧倒的な支持を得ています。' },
  { id: 1, name: 'はなおとでんがん', subscribers: 160, genre: '教育・学習系', mostViewed: '東大生の店員に理系風に注文したら、賢すぎて返り討ちにされました。 (2100万回再生)', strategy: '阪大出身の理系知識をベースにしたコメディ企画が人気。「学びをエンタメ化」する代表格です。' },
  { id: 2, name: 'Stardy -河野玄斗の神授業', subscribers: 157, genre: '教育・学習系', mostViewed: 'Study Music Alpha Waves (7400万回再生)', strategy: '東大医学部・司法試験一発合格という「神脳」ブランドが最大の強み。勉強法からBGMまで学習全般をサポートします。' },
  { id: 3, name: 'ブレイクスルー佐々木', subscribers: 125, genre: '教育・学習系', mostViewed: '地球より生命に適した「スーパーアース」が発見されたってガチ？ (440万回再生)', strategy: '早稲田首席卒の知識を活かし、科学解説ショート動画でブレイク。専門知識を短く分かりやすく伝える能力に長けています。' },
  { id: 4, name: '予備校のノリで学ぶ「大学の数学・物理」', subscribers: 122, genre: '教育・学習系', mostViewed: '宇宙創生から現在まで【宇宙の歴史①(過去編)】 (210万回再生)', strategy: '大学レベルの数学・物理を分かりやすく解説。ニッチながらも学習意欲の高い層から絶大な信頼を得ています。' },
  { id: 5, name: 'GENKI LABO', subscribers: 106, genre: '教育・学習系', mostViewed: '不明', strategy: '科学実験を通じて、子どもから大人まで楽しめる教育エンタメを提供。視覚的な面白さが魅力です。' },
  { id: 6, name: 'ナナオは立派なユーチューバー', subscribers: 89.4, genre: 'ライフスタイル・Vlog系', mostViewed: '【神回】実家への留年通知を強奪し留年を隠蔽する大学生の１日 (310万回再生)', strategy: '「あるあるネタ」や飾らない日常が高い共感を呼び、特に若年層の女性から人気。ショート動画の活用が上手いです。' },
  { id: 7, name: 'Jane', subscribers: 45.2, genre: 'ライフスタイル・Vlog系', mostViewed: 'The last Japanese high school senior vlog (290万回再生)', strategy: '高校卒業から大学生活まで、等身大のライフステージの変化をVlogで記録。洗練された映像美と共感性の高い内容が特徴。' },
  { id: 8, name: 'PASSLABO', subscribers: 37.9, genre: '教育・学習系', mostViewed: '【整数問題】入試頻出解法を"４時間で"全パターン解説 (290万回再生)', strategy: '東大医学部生が「教育格差是正」を掲げ、超実践的な受験勉強法を発信。長尺でも質の高い解説動画が支持されています。' },
  { id: 9, name: 'りゅうが', subscribers: 18.9, genre: 'ライフスタイル・Vlog系', mostViewed: 'TWICE "Alcohol-Free" DANCE COVER (17.8万回再生)', strategy: '現役大学生としての日常Vlogと、得意なK-POPダンスカバーを組み合わせ、同世代のファンを獲得しています。' }
];

// Mountain and photography channel data
const mountainChannelData = {
  'JIN': {
    nation: '日本',
    subscribers: 10.4,
    focus: '高難度な登山の臨場感と映像美',
    popularVideos: [
      { title: '【テント泊登山】断崖絶壁30kmの道...', views: 180 },
      { title: 'Northern Alps Ushirotateyama...', views: 130 },
      { title: 'Hiking Yakushima Island Japan...', views: 24.7 }
    ],
    unpopularVideos: [
      { title: '北アルプス裏銀座・薬師沢にて JINの山小屋', views: 0.28 },
      { title: '北アルプス裏銀座・雲ノ平にて JINの山小屋', views: 0.36 },
      { title: '北アルプス裏銀座・三俣蓮華岳にて...', views: 0.53 }
    ],
    contentAnalysis: `
      <p class="mb-4">JINのチャンネルは「登山の絶景や感動、険しさ、ルート状況」を伝えることに特化しています。まるで映画のような高品質な映像と、登山中の息遣いや風の音まで捉えた没入感の高い音響設計が特徴です。</p>
      <p class="mb-4">視聴者がその場にいるかのようなリアルな緊張感を伝えることで、他のチャンネルとの差別化を図っています。編集技術も高く評価されており、撮影機器に関するテーマも豊富です。</p>
      <p>彼の穏やかで落ち着いた人柄も、コンテンツの静謐な雰囲気に貢献しており、視聴者に安心感を与えています。</p>`,
    audience: `
      <h4 class="font-bold mb-2">ターゲット層</h4>
      <p class="mb-4">実践的な情報を求める初心者から、詳細なルート状況や没入感のある体験を求めるベテランまで、幅広い登山愛好家。</p>
      <h4 class="font-bold mb-2">エンゲージメント</h4>
      <p>高品質な映像と臨場感あふれる体験提供が主なエンゲージメント手法。動画が「登山の予習」として実用的な価値を持つことも、視聴者の忠誠心を高めている。</p>`,
    growth: `
      <p class="mb-4">チャンネル登録者数は着実に増加しており、コンテンツ戦略の成功を示しています。彼の戦略は、短期的なバズを狙うのではなく、長期間視聴され続ける「エバーグリーン」な傑作コンテンツの制作に重点を置いています。</p>
      <p>高難度な挑戦をテーマにした動画は、公開から数年経っても新規視聴者を獲得し続けています。収益化は、撮影機材に関する知見を活かしたブランド提携やアフィリエイトの可能性が考えられます。</p>`
  },
  'かほの登山日記': {
    nation: '日本',
    subscribers: 32.9,
    focus: '共感を呼ぶ登山体験とライフスタイル',
    popularVideos: [
      { title: '【山小屋で年越し】木曽駒ヶ岳を...', views: 24.2 },
      { title: '【デナリ-最終回-】ハイキャンプ...', views: 22.2 },
      { title: 'I have some recent news...', views: 16.1 }
    ],
    unpopularVideos: [
      { title: '[Junigatake - 1,683m] Enjoy the...', views: 1.8 },
      { title: '気象予報士に聞く！ 登山天気アプリ...', views: 1.9 },
      { title: '【山女子のライブ配信】トレラン...', views: 2.3 }
    ],
    contentAnalysis: `
      <p class="mb-4">自身の登山体験の記録を中心に、ギアレビュー、旅行Vlog、個人的な近況報告など、多様なコンテンツを展開。デナリのような高難度遠征から身近な低山まで幅広く扱い、視聴者の共感を呼ぶストーリーテリングが強みです。</p>
      <p class="mb-4">スマートフォンをメインに撮影しつつも、高性能ミラーレスカメラを導入するなど、制作品質の向上にも意欲的。「定期的な投稿」と「流れるような編集」で、視聴者を飽きさせない工夫を凝らしています。</p>
      <p>彼女の親しみやすいキャラクターが前面に出ており、視聴者はクリエイター自身の成長物語に惹きつけられています。</p>`,
    audience: `
      <h4 class="font-bold mb-2">ターゲット層</h4>
      <p class="mb-4">これから登山を始めたいと考えている層や、かつて登山をしていたが今は離れている熟年層が中心。幅広い年齢層にアピール。</p>
      <h4 class="font-bold mb-2">エンゲージメント</h4>
      <p>定期的な投稿と、視聴者が共感できる個人的な物語の共有が核。ライブ配信によるリアルタイム交流や、オリジナルグッズ販売も行い、ファンとの強い繋がりを構築。</p>`,
    growth: `
      <p class="mb-4">開設初期から急速に成長したチャンネル。週2〜3本という高い投稿頻度と、視聴者との密なコミュニケーションが成長を支えています。</p>
      <p>成功の鍵は、クリエイターの人間性や挑戦する姿そのものにあります。収益化は、オリジナルグッズ販売や、Nikonとの連携に見られるようなブランドパートナーシップが中心と考えられます。</p>`
  },
  'Kraig Adams': {
    nation: 'アメリカ',
    subscribers: 79.5,
    focus: 'ミニマリストなソロハイキングと環境音',
    popularVideos: [
      { title: '3 Hours of Ambient Silent Hiking', views: 150 },
      { title: '3 Hours of Ambient Silent Drone...', views: 25.7 },
      { title: '5 Days in Mexico City - ...', views: 27 }
    ],
    unpopularVideos: [
      { title: 'データなし', views: 0 },
      { title: 'データなし', views: 0 },
      { title: 'データなし', views: 0 }
    ],
    contentAnalysis: `
      <p class="mb-4">会話やナレーションを排し、環境音と控えめな音楽、そして美しい映像だけで構成される「ミニマリスト」なスタイルが最大の特徴です。世界各地でのソロハイキングをドキュメントしています。</p>
      <p class="mb-4">5〜12秒という長めのショットで、視聴者が風景に没入する時間を提供。ドローン映像を効果的に使い、壮大な自然の中にいる一人のハイカーという構図で、静寂と孤独の美学を表現します。</p>
      <p>このスタイルは、情報過多の現代社会で「癒し」や「リラックス」を求める視聴者のニーズに合致しています。</p>`,
    audience: `
      <h4 class="font-bold mb-2">ターゲット層</h4>
      <p class="mb-4">落ち着きとリラックスを求める人々が中心。登山家だけでなく、ASMRやアンビエントコンテンツのファン、瞑想的な映像体験を求める層にもアピール。</p>
      <h4 class="font-bold mb-2">エンゲージメント</h4>
      <p>コンテンツ自体が提供する「没入感」と「癒し」が最大のエンゲージメント要因。視聴者は共通の体験（静けさ）を求めて集まり、独自のコミュニティを形成。</p>`,
    growth: `
      <p class="mb-4">明確なニッチを確立し、その分野で圧倒的な存在感を示すことで成長。彼の戦略は、自身のライフスタイルそのものを「商品」として提示し、本物の体験を共有することにあります。</p>
      <p>将来的にはコミュニティ全体を支援する方向性も示しており、持続可能なクリエイターエコシステムの構築を目指しています。収益化は、ライフスタイルに共感するブランドとのパートナーシップが中心と考えられます。</p>`
  },
  'Thomas Heaton': {
    nation: 'イギリス',
    subscribers: 60.1,
    focus: '風景写真のプロセスとアウトドアライフ',
    popularVideos: [
      { title: 'Small Off-Road Camper Van...', views: 110 },
      { title: 'How to Use a Wide Angle Lens', views: 85 },
      { title: 'The UGLY side of Landscape...', views: 78.2 }
    ],
    unpopularVideos: [
      { title: 'A Landscape Photography Micro...', views: 4.8 },
      { title: 'Why I don\'t Do Astrophotography.', views: 6.0 },
      { title: 'Behind the Scenes of my trip...', views: 1.7 }
    ],
    contentAnalysis: `
      <p class="mb-4">風景写真に特化し、撮影技術だけでなく、撮影地への旅、バンライフ、写真家としての思考プロセス全体を共有するスタイルです。成功体験だけでなく、失敗や困難も率直に語る「正直さ」が視聴者の信頼を得ています。</p>
      <p class="mb-4">デジタルとフィルムの両方を扱い、機材選定の理由や使い方についても詳しく解説。彼のコンテンツは、写真の「ハウツー」と、アウトドアでの「冒険物語」が融合したものです。</p>
      <p>美しい完成写真だけでなく、その裏側にあるストーリーを伝えることで、深い共感を呼んでいます。</p>`,
    audience: `
      <h4 class="font-bold mb-2">ターゲット層</h4>
      <p class="mb-4">風景写真家、写真愛好家、アウトドアやバンライフに興味を持つ人々。</p>
      <h4 class="font-bold mb-2">エンゲージメント</h4>
      <p>専門知識の共有と、自身の経験を正直に語るストーリーテリングが核。ブログやニュースレターも活用し、YouTube以外の接点も持つことで、視聴者との関係を深化させている。「リピーター」を重視する姿勢が、忠実なファンベースを構築。</p>`,
    growth: `
      <p class="mb-4">「着実な成長」を重視し、個々の動画のパフォーマンスに一喜一憂しない長期的な視点を持っています。YouTubeを自身のブランドを構築するためのハブと位置づけ、多角的な収益化を目指しています。</p>
      <p>自身のウェブサイトでの作品販売やアフィリエイトマーケティングなど、YouTube広告収入に依存しないビジネスモデルを構築。クリエイターとしての自立性を高めています。</p>`
  }
};

// Export all channel data
export const getAllChannelData = () => {
  return {
    camera: cameraChannelData,
    university: universityChannelData,
    mountain: mountainChannelData,
  };
};