import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import Card from '../components/Card';
import SectionTitle from '../components/SectionTitle';
import ChartContainer from '../components/ChartContainer';
import { getAllChannelData } from '../data/channelData';

const CameraChannels: React.FC = () => {
  const allChannelData = getAllChannelData();
  const [selectedChannel, setSelectedChannel] = useState(allChannelData.camera[0]?.id || '');

  // Get the currently selected channel data
  const channel = allChannelData.camera.find(c => c.id === selectedChannel);
  
  // Format views number for display
  const formatViews = (num: number) => {
    if (num === 0) return '0回';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(0) + 'K';
    return num;
  };

  // Chart data for video performance
  const videoPerformanceData = {
    labels: channel ? [
      channel.mostViewed.title, 
      ...(channel.leastViewed.filter((v: any) => v.views > 0).slice(0, 3).map((v: any) => v.title))
    ] : [],
    datasets: [{
      label: '再生回数',
      data: channel ? [
        channel.mostViewed.views, 
        ...(channel.leastViewed.filter((v: any) => v.views > 0).slice(0, 3).map((v: any) => v.views))
      ] : [],
      backgroundColor: [
        'rgba(2, 132, 199, 0.7)', // sky-700
        'rgba(203, 213, 225, 0.7)', // slate-300
        'rgba(203, 213, 225, 0.7)',
        'rgba(203, 213, 225, 0.7)'
      ],
      borderColor: [
        'rgba(2, 132, 199, 1)',
        'rgba(100, 116, 139, 1)',
        'rgba(100, 116, 139, 1)',
        'rgba(100, 116, 139, 1)'
      ],
      borderWidth: 1
    }]
  };

  const chartOptions = {
    indexAxis: 'y',
    scales: {
      x: {
        type: 'logarithmic',
        title: {
          display: true,
          text: '再生回数 (対数スケール)'
        },
        ticks: {
          callback: function(value: any) {
            return formatViews(value);
          }
        }
      },
      y: {
        ticks: {
          callback: function(value: any, index: number, values: any[]) {
            const label = this.getLabelForValue(value);
            return label.length > 20 ? label.substring(0, 20) + '...' : label;
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return ` 再生回数: ${context.raw.toLocaleString()}回`;
          }
        }
      }
    }
  };

  return (
    <section className="fade-in" id="camera-channels">
      <SectionTitle 
        title="カメラ系YouTubeチャンネル分析"
        subtitle="本セクションでは、日本のカメラ・写真系YouTube市場の動向を可視化し、分析します。プロ写真家による専門性の高いコンテンツから、エンターテイメント性の高い企画まで、非常に多様化しています。以下の分析を通じて、主要チャンネルの戦略やパフォーマンスを深く探ることができます。"
      />

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <Card title="専門性と多様性" accentColor="primary">
          <p className="text-sm text-slate-600">初心者向けハウツー、特定機材の深掘りレビュー、エンタメ企画など、各チャンネルが明確なニッチを確立。視聴者は自身のレベルや興味に合わせてチャンネルを選択できる成熟した市場を形成しています。</p>
        </Card>
        <Card title="プロの影響力" accentColor="primary">
          <p className="text-sm text-slate-600">多くの人気チャンネルはプロ写真家が運営。その専門知識と経験がコンテンツの信頼性を高め、視聴者からの強い支持を得る重要な要因となっています。</p>
        </Card>
        <Card title="ショート動画の役割" accentColor="primary">
          <p className="text-sm text-slate-600">ショート動画は、新規視聴者獲得のための「顔」となるエンタメコンテンツ、または既存ファン向けの補完的コンテンツとして戦略的に活用されています。役割はチャンネルごとに大きく異なります。</p>
        </Card>
      </div>

      <div className="lg:grid lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-4 mb-8 lg:mb-0">
          <div className="card sticky top-24 p-4">
            <h3 className="font-bold text-xl mb-4 text-center">登録者数ランキング TOP 10</h3>
            <div className="space-y-2">
              {allChannelData.camera.map((channel, index) => (
                <div 
                  key={channel.id}
                  className={`p-3 rounded-md border-l-4 hover:bg-sky-50 cursor-pointer transition-colors ${
                    selectedChannel === channel.id 
                      ? 'border-sky-500 bg-sky-50' 
                      : 'border-slate-200 bg-slate-50'
                  }`}
                  onClick={() => setSelectedChannel(channel.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <span className="font-bold text-slate-500 w-6">{index + 1}.</span>
                      <span className="font-medium text-slate-700">{channel.name}</span>
                    </div>
                    <span className="text-sm font-bold text-sky-600">{(channel.subs / 1000).toFixed(1)}K</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-8">
          <Card className="min-h-[80vh]">
            {channel ? (
              <div>
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
                  <div>
                    <h3 className="text-3xl font-bold text-slate-800">{channel.name}</h3>
                    <p className="text-slate-500 font-medium">{(channel.subs / 1000).toFixed(1)}K Subscribers</p>
                  </div>
                  <a 
                    href={channel.link} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="mt-4 md:mt-0 btn btn-primary flex items-center"
                  >
                    YouTubeで見る <ChevronRight size={16} className="ml-1" />
                  </a>
                </div>

                <div className="space-y-10">
                  <div>
                    <h4 className="font-bold text-lg mb-3 text-slate-700">コンテンツ概要</h4>
                    <p className="text-sm leading-relaxed text-slate-600 bg-slate-50 p-4 rounded-md">{channel.summary}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-lg mb-3 text-slate-700">動画パフォーマンス：再生数の両極端</h4>
                    <p className="text-sm text-slate-500 mb-4">チャンネル内で最も再生された動画と、再生数が少ない動画のパフォーマンス比較。ニッチなテーマとバイラルヒットの差が顕著に現れます。</p>
                    <ChartContainer
                      id="camera-video-performance-chart"
                      type="bar"
                      data={videoPerformanceData}
                      options={chartOptions}
                      height="300px"
                    />
                  </div>
                  
                  <div>
                    <h4 className="font-bold text-lg mb-3 text-slate-700">ショート動画 vs 通常動画</h4>
                    <div className="text-sm text-slate-600 bg-slate-50 p-4 rounded-md">
                      {channel.shortsAnalysis}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <svg className="w-16 h-16 text-slate-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path>
                </svg>
                <h3 className="text-xl font-bold text-slate-600">詳細な分析を表示</h3>
                <p className="text-slate-500 mt-2">左のリストからチャンネルを選択してください。</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
};

export default CameraChannels;