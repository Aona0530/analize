import React, { useState } from 'react';
import Card from '../components/Card';
import SectionTitle from '../components/SectionTitle';
import ChartContainer from '../components/ChartContainer';
import Modal from '../components/Modal';
import { getAllChannelData } from '../data/channelData';

const MountainChannels: React.FC = () => {
  const allChannelData = getAllChannelData();
  const [modalOpen, setModalOpen] = useState(false);
  const [modalChannelName, setModalChannelName] = useState('');

  // Chart data for subscriber comparison
  const labels = Object.keys(allChannelData.mountain);
  const subscriberData = labels.map(label => allChannelData.mountain[label].subscribers);

  const subscriberChartData = {
    labels: labels,
    datasets: [{
      label: 'チャンネル登録者数 (万人)',
      data: subscriberData,
      backgroundColor: [
        'rgba(120, 113, 108, 0.6)', // stone-500
        'rgba(214, 69, 65, 0.6)',  // red-500
        'rgba(74, 85, 104, 0.6)',  // slate-600
        'rgba(4, 120, 87, 0.6)'    // emerald-600
      ],
      borderColor: [
        'rgba(120, 113, 108, 1)',
        'rgba(214, 69, 65, 1)',
        'rgba(74, 85, 104, 1)',
        'rgba(4, 120, 87, 1)'
      ],
      borderWidth: 1
    }]
  };

  const subscriberChartOptions = {
    indexAxis: 'y',
    scales: {
      x: {
        beginAtZero: true,
        title: {
          display: true,
          text: '登録者数 (万人)'
        }
      },
      y: {
        grid: {
          display: false
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ${context.raw} 万人`;
          }
        }
      }
    }
  };

  const openModal = (name: string) => {
    setModalChannelName(name);
    setModalOpen(true);
  };

  // Video performance chart generator
  const createVideoPerformanceChartData = (channelName: string) => {
    const channel = allChannelData.mountain[channelName];
    if (!channel) return { data: null, options: null };

    const popular = channel.popularVideos;
    const unpopular = channel.unpopularVideos;

    // Skip if no valid data
    if (popular[0].title === 'データなし' || popular[0].views === 0) {
      return { data: null, options: null };
    }

    const data = {
      labels: ['人気動画 1', '人気動画 2', '人気動画 3', '低調動画 1', '低調動画 2', '低調動画 3'],
      datasets: [{
        label: '再生回数 (万回)',
        data: [...popular.map(v => v.views), ...unpopular.map(v => v.views)],
        backgroundColor: [
          '#34D399', '#34D399', '#34D399', // emerald-400
          '#F87171', '#F87171', '#F87171'  // red-400
        ],
        borderWidth: 0
      }]
    };

    const options = {
      scales: {
        y: {
          type: 'logarithmic',
          beginAtZero: true,
          title: {
            display: true,
            text: '再生回数 (万回・対数)'
          }
        },
        x: {
          ticks: {
            callback: function(val: any, index: number) {
              return this.getLabelForValue(val).length > 10 
                ? this.getLabelForValue(val).substring(0,10)+'...' 
                : this.getLabelForValue(val);
            }
          }
        }
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          callbacks: {
            title: function(tooltipItems: any) {
              const videoIndex = tooltipItems[0].dataIndex;
              const isPopular = videoIndex < 3;
              const videos = isPopular ? popular : unpopular;
              const index = isPopular ? videoIndex : videoIndex - 3;
              return videos[index].title;
            },
            label: function(context: any) {
              return `再生回数: ${context.raw.toFixed(2)} 万回`;
            }
          }
        }
      }
    };

    return { data, options };
  };

  return (
    <section className="fade-in" id="mountain-photo-channels">
      <SectionTitle 
        title="登山・写真系YouTuber 戦略分析" 
        subtitle="本セクションでは、登山と写真という特定のニッチに特化したYouTubeチャンネルの戦略を深掘りします。彼らがどのように視聴者を惹きつけ、コンテンツを制作し、成長を遂げているかを分析します。"
        centered={true}
      />

      <Card className="mb-12">
        <h3 className="text-xl font-bold mb-4 text-stone-800">チャンネル登録者数 (万人)</h3>
        <ChartContainer 
          id="mountain-subscriberChart"
          type="bar"
          data={subscriberChartData}
          options={subscriberChartOptions}
        />
      </Card>

      <h3 className="text-2xl font-bold text-slate-800 mb-6 text-center">コンテンツ戦略分析</h3>
      <p className="text-center text-lg text-slate-600 max-w-3xl mx-auto mb-10">
        各チャンネルのコンテンツ戦略とパフォーマンスを掘り下げます。人気動画と再生数が伸び悩んだ動画のパフォーマンスギャップを可視化し、各クリエイターの独自スタイルや制作へのこだわりを分析します。
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {Object.keys(allChannelData.mountain).map(name => {
          const data = allChannelData.mountain[name];
          const chartData = createVideoPerformanceChartData(name);
          const canvasId = `mountain-videoChart-${name.replace(/\s+/g, '-')}`;
          
          return (
            <Card key={name}>
              <div className="flex items-baseline justify-between mb-4">
                <h3 className="text-2xl font-bold text-stone-800">{name}</h3>
                <span className="text-sm font-medium text-stone-500 bg-stone-100 px-2 py-1 rounded-full">{data.nation}</span>
              </div>
              <p className="text-stone-600 mb-4">{data.focus}</p>
              
              <h4 className="text-lg font-semibold mb-2 text-stone-700">人気・低調動画パフォーマンス</h4>
              {chartData.data ? (
                <ChartContainer
                  id={canvasId}
                  type="bar"
                  data={chartData.data}
                  options={chartData.options}
                  height="250px"
                />
              ) : (
                <div className="h-64 flex items-center justify-center bg-slate-50 rounded-lg">
                  <p className="text-center text-stone-500">パフォーマンスデータがありません</p>
                </div>
              )}
              
              <button 
                className="w-full mt-4 bg-stone-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-stone-800 transition-colors"
                onClick={() => openModal(name)}
              >
                詳細な戦略分析を見る
              </button>
            </Card>
          );
        })}
      </div>

      <h3 className="text-2xl font-bold text-slate-800 mb-6 text-center">視聴者とコミュニティ</h3>
      <p className="text-center text-lg text-slate-600 max-w-3xl mx-auto mb-10">
        クリエイターがどのように視聴者と関わり、コミュニティを築いているかを探ります。各チャンネルがどのような層に支持され、どのような価値提供によってファンを惹きつけているのかを比較します。
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 mb-12">
        {Object.keys(allChannelData.mountain).map(name => {
          const data = allChannelData.mountain[name];
          
          return (
            <Card key={`audience-${name}`}>
              <h3 className="text-xl font-bold text-stone-800 mb-4">{name}</h3>
              <div 
                className="text-stone-700 space-y-4" 
                dangerouslySetInnerHTML={{ __html: data.audience }}
              />
            </Card>
          );
        })}
      </div>

      <h3 className="text-2xl font-bold text-slate-800 mb-6 text-center">成長と収益化戦略</h3>
      <p className="text-center text-lg text-slate-600 max-w-3xl mx-auto mb-10">
        各チャンネルの持続的な成長と収益化の戦略を分析します。単なる広告収入に留まらない、多角的なアプローチと長期的なビジョンに焦点を当てます。
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {Object.keys(allChannelData.mountain).map(name => {
          const data = allChannelData.mountain[name];
          
          return (
            <Card key={`growth-${name}`}>
              <h3 className="text-xl font-bold text-stone-800 mb-4">{name}</h3>
              <div 
                className="text-stone-700 space-y-4" 
                dangerouslySetInnerHTML={{ __html: data.growth }}
              />
            </Card>
          );
        })}
      </div>

      {/* Modal for strategy details */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={`${modalChannelName} のコンテンツ戦略`}
        size="lg"
      >
        {modalChannelName && (
          <div 
            className="text-stone-700 space-y-4" 
            dangerouslySetInnerHTML={{ 
              __html: allChannelData.mountain[modalChannelName]?.contentAnalysis || '情報がありません。' 
            }}
          />
        )}
      </Modal>
    </section>
  );
};

export default MountainChannels;