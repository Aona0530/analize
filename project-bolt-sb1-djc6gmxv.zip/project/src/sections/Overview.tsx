import React from 'react';
import { Camera, GraduationCap, Mountain } from 'lucide-react';
import Card from '../components/Card';
import SectionTitle from '../components/SectionTitle';
import ChartContainer from '../components/ChartContainer';
import { getAllChannelData } from '../data/channelData';

interface OverviewProps {
  onSectionChange: (sectionId: string) => void;
}

const Overview: React.FC<OverviewProps> = ({ onSectionChange }) => {
  const allChannelData = getAllChannelData();

  // Calculate total subscribers for each category
  const cameraSubs = allChannelData.camera.reduce((sum, c) => sum + (c.subs / 10000), 0); // Convert to 万人
  const universitySubs = allChannelData.university.reduce((sum, c) => sum + c.subscribers, 0); // Already in 万人
  const mountainSubs = Object.values(allChannelData.mountain).reduce((sum, c) => sum + c.subscribers, 0); // Already in 万人

  // Chart data
  const subscriberChartData = {
    labels: ['カメラ系チャンネル', '大学生YouTuber', '登山・写真系YouTuber'],
    datasets: [{
      label: '合計登録者数 (万人)',
      data: [cameraSubs, universitySubs, mountainSubs],
      backgroundColor: [
        'rgba(14, 165, 233, 0.7)', // sky-500
        'rgba(59, 130, 246, 0.7)', // blue-500
        'rgba(16, 185, 129, 0.7)'  // emerald-500
      ],
      borderColor: [
        'rgba(14, 165, 233, 1)',
        'rgba(59, 130, 246, 1)',
        'rgba(16, 185, 129, 1)'
      ],
      borderWidth: 1
    }]
  };

  const chartOptions = {
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: '合計登録者数 (万人)'
        }
      },
      x: {
        grid: {
          display: false
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return ` ${context.raw.toFixed(1)} 万人`;
          }
        }
      }
    }
  };

  return (
    <section className="fade-in" id="home">
      <SectionTitle 
        title="統合ダッシュボード: 日本のYouTuber市場" 
        subtitle="本ダッシュボードは、日本のYouTube市場における主要なニッチ（カメラ、大学生、登山・写真）の動向を統合的に可視化し、分析するためのツールです。各セクションをクリックして、詳細なデータと戦略を探ることができます。"
        centered={true}
      />

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <Card 
          title="カメラ系チャンネル" 
          icon={<Camera size={20} />}
          accentColor="primary"
          onClick={() => onSectionChange('camera-channels')}
        >
          <p className="text-sm text-slate-600">プロ写真家による専門性の高いコンテンツからエンタメ企画まで、多様なチャンネルを分析。</p>
        </Card>

        <Card 
          title="大学生YouTuber" 
          icon={<GraduationCap size={20} />}
          accentColor="secondary"
          onClick={() => onSectionChange('university-channels')}
        >
          <p className="text-sm text-slate-600">教育・学習系とライフスタイル・Vlog系の二大勢力。共感性と専門性が鍵。</p>
        </Card>

        <Card 
          title="登山・写真系YouTuber" 
          icon={<Mountain size={20} />}
          accentColor="success"
          onClick={() => onSectionChange('mountain-photo-channels')}
        >
          <p className="text-sm text-slate-600">臨場感ある映像美と体験共有。ニッチなテーマでの成長戦略。</p>
        </Card>
      </div>

      <Card className="mt-12">
        <h2 className="text-2xl font-bold mb-4 text-slate-800">各カテゴリ登録者数合計 (上位チャンネル)</h2>
        <p className="text-slate-600 mb-6">各カテゴリの上位チャンネル登録者数を合計して比較しています。市場規模の概観としてご覧ください。</p>
        <ChartContainer 
          id="overviewCombinedSubsChart"
          type="bar"
          data={subscriberChartData}
          options={chartOptions}
        />
      </Card>
    </section>
  );
};

export default Overview;