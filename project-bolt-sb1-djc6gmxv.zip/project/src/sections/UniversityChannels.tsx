import React, { useState } from 'react';
import Card from '../components/Card';
import SectionTitle from '../components/SectionTitle';
import ChartContainer from '../components/ChartContainer';
import { getAllChannelData } from '../data/channelData';

const UniversityChannels: React.FC = () => {
  const allChannelData = getAllChannelData();
  const [selectedChannelId, setSelectedChannelId] = useState<number>(allChannelData.university[0]?.id || 0);

  // Get the currently selected channel
  const selectedChannel = allChannelData.university.find(c => c.id === selectedChannelId);

  // Chart data for subscriber rankings
  const subscriberChartData = {
    labels: allChannelData.university.map(c => c.name),
    datasets: [{
      label: '登録者数 (万人)',
      data: allChannelData.university.map(c => c.subscribers),
      backgroundColor: 'rgba(2, 132, 199, 0.7)', // sky-700
      borderColor: 'rgba(2, 132, 199, 1)',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(2, 132, 199, 1)',
    }]
  };

  const subscriberChartOptions = {
    indexAxis: 'y',
    scales: {
      x: {
        beginAtZero: true,
        title: {
          display: true,
          text: '登録者数 (万人)'
        }
      },
      y: {
        ticks: {
          font: {
            size: 10
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return ` ${context.raw.toLocaleString()} 万人`;
          }
        }
      }
    }
  };

  // Genre distribution chart data
  const genreCounts = allChannelData.university.reduce((acc: Record<string, number>, channel) => {
    acc[channel.genre] = (acc[channel.genre] || 0) + 1;
    return acc;
  }, {});

  const genreChartData = {
    labels: Object.keys(genreCounts),
    datasets: [{
      data: Object.values(genreCounts),
      backgroundColor: [
        'rgba(2, 132, 199, 0.7)', // sky-700
        'rgba(245, 158, 11, 0.7)', // amber-500
      ],
      borderColor: [
        'rgba(2, 132, 199, 1)',
        'rgba(245, 158, 11, 1)',
      ],
      borderWidth: 1
    }]
  };

  const genreChartOptions = {
    plugins: {
      legend: {
        position: 'top',
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return ` ${context.label}: ${context.raw} チャンネル`;
          }
        }
      }
    }
  };

  // Audience motivation chart data
  const audienceChartData = {
    labels: ['暇つぶし', '情報収集', '推し活'],
    datasets: [
      {
        label: '男性',
        data: [65, 45, 20],
        backgroundColor: 'rgba(2, 132, 199, 0.7)', // sky-700
        borderColor: 'rgba(2, 132, 199, 1)',
        borderWidth: 1
      },
      {
        label: '女性',
        data: [70, 30, 40],
        backgroundColor: 'rgba(236, 72, 153, 0.7)', // pink-500
        borderColor: 'rgba(236, 72, 153, 1)',
        borderWidth: 1
      }
    ]
  };

  const audienceChartOptions = {
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        title: {
          display: true,
          text: '回答率 (%)'
        }
      }
    },
    plugins: {
      legend: {
        position: 'top',
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ${context.raw}%`;
          }
        }
      }
    }
  };

  return (
    <section className="fade-in" id="university-channels">
      <SectionTitle 
        title="日本人大学生YouTuberの世界" 
        subtitle="このセクションでは、日本人大学生YouTuberに焦点を当て、その動向と成功要因を深掘りします。学業と両立しながらコンテンツ制作を行う彼らの戦略を分析します。"
      />

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <Card title="教育とエンタメの融合" accentColor="primary">
          <p className="text-sm text-slate-600">高学歴を背景とした専門性と、エンターテイメント性の高い企画力を組み合わせることで、「学び」と「楽しさ」を両立させています。</p>
        </Card>
        <Card title="共感性の重視" accentColor="primary">
          <p className="text-sm text-slate-600">学生ならではの日常や悩み、成長過程を共有することで、同世代の視聴者との強い心理的結びつきを形成しています。</p>
        </Card>
        <Card title="マルチコンテンツ戦略" accentColor="primary">
          <p className="text-sm text-slate-600">ショート動画での新規視聴者獲得と、通常動画でのファン定着を組み合わせた効果的なコンテンツ戦略を展開しています。</p>
        </Card>
      </div>

      <Card className="mb-12">
        <h3 className="text-2xl font-bold mb-4 text-slate-800">トップ10チャンネル 登録者数ランキング</h3>
        <p className="text-slate-600 mb-6">このグラフは、調査対象となった日本人大学生YouTuberの中で、登録者数が最も多い上位10チャンネルを示しています。各バーをクリックすると、該当チャンネルの詳細な分析データが表示されます。</p>
        <ChartContainer 
          id="university-subscriberChart"
          type="bar"
          data={subscriberChartData}
          options={subscriberChartOptions}
        />
      </Card>

      <div className="lg:grid lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-4 mb-8 lg:mb-0">
          <div className="sticky top-24">
            <Card>
              <h3 className="text-xl font-bold mb-4 text-slate-800">チャンネル選択</h3>
              <select 
                className="w-full p-3 border border-slate-300 rounded-lg bg-slate-50 focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                value={selectedChannelId}
                onChange={(e) => setSelectedChannelId(parseInt(e.target.value))}
              >
                {allChannelData.university.map(channel => (
                  <option key={channel.id} value={channel.id}>{channel.name}</option>
                ))}
              </select>
            </Card>

            <Card className="mt-6">
              <h3 className="text-xl font-bold mb-4 text-slate-800">ジャンル分布</h3>
              <ChartContainer 
                id="university-genreChart"
                type="doughnut"
                data={genreChartData}
                options={genreChartOptions}
                height="250px"
              />
            </Card>
          </div>
        </div>

        <div className="lg:col-span-8">
          <Card className="min-h-[80vh]">
            {selectedChannel ? (
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-bold text-slate-800">{selectedChannel.name}</h3>
                  <p className="text-slate-500 font-medium">{selectedChannel.subscribers}万人</p>
                </div>

                <div className="flex items-center space-x-2">
                  <span className={`text-sm font-semibold py-1 px-3 rounded-full ${
                    selectedChannel.genre === '教育・学習系' 
                      ? 'bg-sky-100 text-sky-800' 
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {selectedChannel.genre}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-lg mb-2 text-slate-700">最多再生動画</h4>
                  <p className="text-sm text-slate-600 bg-slate-50 p-4 rounded-md">
                    {selectedChannel.mostViewed}
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-lg mb-2 text-slate-700">チャンネル分析</h4>
                  <p className="text-sm text-slate-600 bg-slate-50 p-4 rounded-md">
                    {selectedChannel.strategy}
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-lg mb-2 text-slate-700">視聴者層の特徴</h4>
                  <ChartContainer 
                    id="university-audienceChart"
                    type="bar"
                    data={audienceChartData}
                    options={audienceChartOptions}
                    height="300px"
                  />
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <h3 className="text-xl font-bold text-slate-600">チャンネルを選択してください</h3>
                <p className="text-slate-500 mt-2">左のドロップダウンメニューからチャンネルを選択すると、詳細な分析が表示されます。</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
};

export default UniversityChannels;