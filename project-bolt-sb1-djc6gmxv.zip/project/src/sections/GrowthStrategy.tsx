import React from 'react';
import { Target, BookOpen, Leaf } from 'lucide-react';
import Card from '../components/Card';
import SectionTitle from '../components/SectionTitle';

const GrowthStrategy: React.FC = () => {
  return (
    <section className="fade-in" id="growth-strategy">
      <SectionTitle 
        title="【特別分析】大学生×写真×登山YouTuber 成長戦略" 
        subtitle="これまでの分析を統合し、もし「大学生」が「写真」と「登山」をテーマにしたYouTubeチャンネルを立ち上げた場合の、成功に向けた戦略とターゲット層を提案します。"
        centered={true}
      />

      <div className="space-y-8">
        <Card title="ターゲット層の明確化" icon={<Target size={20} />} accentColor="secondary">
          <ul className="list-disc list-inside text-slate-700 space-y-2 pl-4">
            <li><strong>主要ターゲット：</strong> 18〜25歳の大学生・若年層。特に、カメラやアウトドアに興味はあるが、まだ本格的に始めていない層。</li>
            <li><strong>二次ターゲット：</strong> 自然や美しい景色に癒しを求める社会人層、既存の登山・写真愛好家。</li>
            <li><strong>ペルソナ例：</strong> 「SNSで映える写真を撮りたいけど、どうしたらいいか分からない大学生」「新しい趣味として登山に挑戦したいが、一歩踏み出せない大学生」</li>
          </ul>
        </Card>

        <Card title="コンテンツ戦略：3つの柱" icon={<BookOpen size={20} />} accentColor="success">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <h4 className="font-semibold text-lg text-emerald-800 mb-2">1. 共感性×ライフスタイルVlog</h4>
              <p className="text-sm text-emerald-700">大学生の日常、学業との両立、サークル活動、友だちとの交流の中に登山や写真を取り入れる。親しみやすい「あるある」ネタや、等身大の挑戦（例: 初めての〇〇登山、テスト期間中の息抜き撮影）で共感を呼ぶ。</p>
              <p className="text-sm text-emerald-700 mt-2"><strong>例:</strong> 「バイト代で初めてのミラーレス一眼購入！富士山で試し撮り」「大学の登山サークルに入ってみたVlog」</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <h4 className="font-semibold text-lg text-emerald-800 mb-2">2. 専門性×実践的ハウツー</h4>
              <p className="text-sm text-emerald-700">大学生でも手が届く機材紹介（中古含む）、初心者向けの登山装備解説、スマホでもできる絶景写真術、登山中の安全対策など、実用的な情報を提供。簡潔かつ分かりやすい解説を心がける。</p>
              <p className="text-sm text-emerald-700 mt-2"><strong>例:</strong> 「大学生向け！予算3万円で始める登山ギア」「iPhoneで星空を撮る方法」</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200 md:col-span-2">
              <h4 className="font-semibold text-lg text-emerald-800 mb-2">3. 没入感×映像美コンテンツ</h4>
              <p className="text-sm text-emerald-700">JINやKraig Adamsの要素を取り入れ、会話を最小限に抑え、BGMと環境音、美しい映像で登山や撮影の臨場感を伝える。特にショート動画でインパクトのある絶景映像を配信。</p>
              <p className="text-sm text-emerald-700 mt-2"><strong>例:</strong> 「北アルプス縦走ドローン空撮」「雨の日の森のVlog：水の音と緑の美しさ」</p>
            </div>
          </div>
        </Card>

        <Card title="成長戦略と収益化" icon={<Leaf size={20} />} accentColor="primary">
          <ul className="list-disc list-inside text-slate-700 space-y-2 pl-4">
            <li><strong>ショート動画の活用:</strong> 新規視聴者獲得のフックとして、短時間で「映える」写真や登山のハイライトを定期的に投稿。</li>
            <li><strong>コミュニティ形成:</strong> 視聴者からの質問に答えるQ&A動画、ライブ配信、SNSでの積極的な交流を通じてファンとの絆を深める。</li>
            <li><strong>ブランドパートナーシップ:</strong> 大学生向けアウトドアブランド、カメラメーカー、旅行関連企業などとのタイアップ。自身のライフスタイルと製品を自然に融合させる。</li>
            <li><strong>アフィリエイト:</strong> 動画で紹介した機材やアイテムのリンクを概要欄に記載。</li>
            <li><strong>オリジナルグッズ:</strong> 登山や写真に関するシンプルで実用的なオリジナルTシャツ、キャップなどの販売。</li>
            <li><strong>（将来的な展望）メンバーシップ:</strong> より深い情報（限定Vlog、撮影地情報、編集テクニック）を求める熱心なファン向け。</li>
          </ul>
        </Card>

        <Card title="差別化のポイント" accentColor="accent">
          <ul className="list-disc list-inside text-slate-700 space-y-2 pl-4">
            <li><strong>「等身大の大学生」:</strong> プロにはない親近感と、リアルな挑戦・成長の過程を見せる。</li>
            <li><strong>「写真×登山」の融合:</strong> 登山過程だけでなく、そこで得られる写真の美しさや、撮影の工夫にフォーカスすることで独自性を出す。</li>
            <li><strong>「学び」と「エンタメ」のバランス:</strong> 教育系YouTuberの「分かりやすさ」と、ライフスタイル系の「共感性」を組み合わせる。</li>
          </ul>
        </Card>
      </div>
    </section>
  );
};

export default GrowthStrategy;